# Valence

Valence is a local issue tracker for agents with support for multi-agentic development, written in TypeScript with Drizzle ORM and SQLite. It runs on Node.js using `better-sqlite3`. Store issues inside the project at `.valence/sqlite.db`, or outside it at `~/.config/valence/<project-name>/sqlite.db`.

## Install from this repository

Use Node.js 20.19 or later and npm.

```sh
npm install
npm run typecheck
npm test
npm pack
npm install --global ./valence-0.1.0.tgz
vl --help
```

## CLI

Run `vl` from the project directory.

### Choose storage

In a terminal, `vl init` opens an option selector:

1. Project directory, selected by default. Creates `<project>/.valence/sqlite.db`.
2. User configuration. Creates `~/.config/valence/<project-name>/sqlite.db`. For a project folder named `anvil`, this is `~/.config/valence/anvil/sqlite.db`.

Use the arrow keys and Enter. Ctrl+C cancels without creating either storage directory. The selector shows the full database paths.

For scripts and agents, select a location explicitly:

```sh
vl init --local
vl init --config --json
```

`--local` and `--config` cannot be combined. With `--json` or non-interactive input, no selector opens. Initialization reuses an existing database, or defaults to local storage for a new project. JSON output reports the absolute database path.

### Work with issues

```sh
vl init
vl create "Add storage" \
  --description "Persist issues in SQLite" \
  --checklist "Implement persistence" \
  --checklist "Test reopening the database" \
  --validation "Run npm test" \
  --label backend \
  --priority high

vl list
vl show <id>
vl ready
vl start <id>
vl complete <id> --confirm-checklist --evidence "npm test passed: 12 tests"
```

Use `vl claim` to atomically start the highest-priority ready issue. Multiple clients can claim different issues without claiming the same issue twice. `vl ready` only lists candidates; it does not reserve them.

All commands accept `--json`. Lists return arrays, issue operations return an issue object, and `claim --json` returns `null` when no issue is ready. Errors go to stderr with exit code 1 and no stdout. Empty lists and claims exit successfully.

| Command                | Behavior                                                                                    |
| ---------------------- | ------------------------------------------------------------------------------------------- |
| `init`                 | Select local or config storage, create the database, and apply pending generated migrations |
| `create <title>`       | Create a queued issue with the supplied fields                                              |
| `create --file <path>` | Create an issue from a JSON object                                                          |
| `update <id>`          | Replace supplied fields on a queued or manually blocked issue                               |
| `show <id>`            | Show all fields, checklist, and unmet dependencies                                          |
| `list`                 | List issues in creation order, including dependency-blocking information                    |
| `ready`                | List queued issues whose dependencies are complete                                          |
| `claim`                | Atomically select and start the first ready issue                                           |
| `start <id>`           | Start a specific ready issue                                                                |
| `complete <id>`        | Complete working work with checklist confirmations and evidence                             |
| `block <id>`           | Manually block queued or working work                                                       |
| `requeue <id>`         | Return blocked or interrupted working work to the queue                                     |

### JSON input

Agents can use JSON files instead of field flags:

```json
{
  "title": "Add the issue list",
  "description": "Display the stored issues",
  "checklist": ["Render the list", "Test an empty list"],
  "validation": "Run the list tests",
  "labels": ["cli"],
  "priority": "medium",
  "dependencies": []
}
```

```sh
vl create --file issue.json --json
vl update <id> --file changes.json --json
vl complete <id> --file completion.json --json
```

A completion file contains one boolean per checklist item and nonempty evidence:

```json
{
  "checklist": [true, true],
  "evidence": "npm test -- tests/list.test.ts: 3 passed, 0 failed"
}
```

Valence checks that every confirmation is exactly `true`. It records the caller's evidence; it cannot verify whether that evidence is truthful. The caller runs the actual validation.

### Dependencies and updates

Use the full stable issue IDs printed by `create`:

```sh
vl create "Implement the client" \
  --description "Use the storage interface" \
  --checklist "Add client tests" \
  --validation "Run client tests" \
  --dependency <storage-issue-id>

vl update <id> --priority urgent
vl update <id> --dependency <first-id> --dependency <second-id>
```

Repeated `--dependency`, `--label`, and `--checklist` flags set the complete array, not additions to the existing array. To clear dependencies, use `update --file` with `{"dependencies":[]}`. `--file` cannot be mixed with field flags.

Missing dependencies, duplicate entries, self-dependencies, and cycles are rejected without saving a partial update. Working and completed issues cannot be edited. Stop a worker before explicitly blocking or requeueing its issue; Valence does not own worker processes or track worker leases.

## TypeScript library

Install the packed artifact as a dependency, or use a published release when available. Consumers import only from `valence`, not its source files or database schema. CommonJS `require('valence')` and ESM named imports are supported.

```ts
import { initializeTracker, openTracker } from 'valence'

// Explicit setup only. Applies generated migrations.
const tracker = initializeTracker('/absolute/project/path')
try {
  const [storage, client] = tracker.createMany([
    { key: 'storage', title: 'Add storage', description: 'Persist data', checklist: ['Test persistence'], validation: 'Run storage tests' },
    { key: 'client', title: 'Add client', description: 'Use storage', checklist: ['Test client'], validation: 'Run client tests', dependencies: ['storage'] }
  ])
  const issue = tracker.claim({ ids: [storage!.id, client!.id] })
  // Perform the issue's work and validation before calling tracker.complete(...).
} finally {
  tracker.close()
}

// Ordinary reads and mutations do not initialize storage or apply migrations.
const reopened = openTracker('/absolute/project/path')
reopened.close()
```

`createMany` accepts a nonempty array of `BatchIssue` objects. Each has a unique temporary `key` plus the normal creation fields. Dependencies can reference batch keys, including later entries, or existing issue IDs. Keys cannot shadow existing IDs. The entire batch is validated and committed atomically in input order. Invalid graphs save nothing. Keys are not persisted as issue fields.

`claim()` considers all project issues. `claim({ ids })` restricts selection to those IDs while preserving dependency and priority rules. An empty selection claims nothing. Missing or malformed `ids` in a selection object are errors, not a fallback to global work. These batch and selection interfaces are library-only; the CLI continues to create individual issues and claim globally.

The other methods are `create`, `update`, `get`, `list`, `ready`, `start`, `complete`, `block`, `requeue`, and idempotent `close`. `databasePath` exposes the resolved storage path. `openTracker` throws `TrackerNotInitializedError` if setup is needed; other storage errors must not be treated as permission to create or reset a database.

Valence has no client-specific task IDs, agent ownership, scheduling loops, prompts, or Git policy. Clients keep their own associations to issue IDs. Opening storage does not reset working issues. One agent, multiple agents, desktop applications, and other automation can use the same database through these interfaces.

### Electron consumers

Keep `valence` and `better-sqlite3` external to the main-process bundle. Install a package copy rather than linking a Node checkout, then rebuild its SQLite addon for the consuming Electron version. Ship Valence's `drizzle/` directory and unpack native addons from ASAR. A separate global `vl` installation uses its own Node-compatible addon and can access the same SQLite database.

## Development

```sh
npm ci
npm test
npm run typecheck
npm run build
npm run db:generate
```
