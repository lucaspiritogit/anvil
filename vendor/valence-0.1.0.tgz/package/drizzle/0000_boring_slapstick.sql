CREATE TABLE `issues` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`description` text NOT NULL,
	`checklist` text NOT NULL,
	`validation` text NOT NULL,
	`labels` text NOT NULL,
	`priority` text NOT NULL,
	`dependencies` text NOT NULL,
	`status` text NOT NULL,
	`evidence` text,
	`completed_at` integer
);
